'''
Author: Michael Lewis
Student ID: U14985193
Class: Information Structures
Instructor: Professor Pinsky
Lecture: 1
Date: 9/4/19
Homework Problem: 1.1
'''

'''A simple program that prints welcome messages to the console'''

def main():
    '''Print three welcome messages to the console'''
    print("Welcome to Python\nWelcome to Computer Science\nProgramming is fun")

if __name__ == "__main__":
    main()
else:
    pass