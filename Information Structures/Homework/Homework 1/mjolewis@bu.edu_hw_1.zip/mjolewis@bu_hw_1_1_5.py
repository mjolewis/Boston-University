'''
Author: Michael Lewis
Student ID: U14985193
Class: Information Structures
Instructor: Professor Pinsky
Lecture: 1
Date: 9/4/19
Homework Problem: 1.5
'''

'''A simple program that computes the result of a given expression'''

def computeExpression():
    '''Compute and display the result of an expression'''
    return ((9.5 * 4.5) - (2.5 * 3)) / (45.5 - 3.5)

def main():
    print(computeExpression())

if __name__ == "__main__":
    main()
else:
    pass