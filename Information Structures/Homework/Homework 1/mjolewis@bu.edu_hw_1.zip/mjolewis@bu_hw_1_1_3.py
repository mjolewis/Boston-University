'''
Author: Michael Lewis
Student ID: U14985193
Class: Information Structures
Instructor: Professor Pinsky
Lecture: 1
Date: 9/4/19
Homework Problem: 1.3
'''

'''A simple program that prints a pattern to the console'''

def printPattern():
    '''Prints a string pattern to the console'''
    print("FFFFFFF   U     U   NN    NN\
         \nFF        U     U   NNN   NN\
         \nFFFFFFF   U     U   NN N  NN\
         \nFF         U   U    NN  N NN\
         \nFF          UUU     NN   NNN")

def main():
    printPattern()

if __name__ == "__main__":
    main()
else:
    pass

