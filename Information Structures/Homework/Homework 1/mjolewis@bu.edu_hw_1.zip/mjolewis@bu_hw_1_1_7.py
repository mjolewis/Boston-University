'''
Author: Michael Lewis
Student ID: U14985193
Class: Information Structures
Instructor: Professor Pinsky
Lecture: 1
Date: 9/4/19
Homework Problem: 1.7
'''

# Approximate PI and print the results
def main():
    PI_1 = 4 * (1 - 1 / 3 + 1 / 5 - 1 / 7 + 1 / 9 - 1 / 11)
    PI_2 = 4 * (1 - 1 / 3 + 1 / 5 - 1 / 7 + 1 / 9 - 1 / 11 + 1 / 13 - 1 / 15)
    print("PI is approximately: ", PI_1)
    print("PI is approximately: ", PI_2)

if __name__ == "__main__":
    main()
else: 
    pass